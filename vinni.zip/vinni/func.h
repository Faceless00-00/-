#ifndef __FUNC_H__
#define __FUNC_H__
    void read_file (const char* name, char* in_all_data);
    void write_file (const char * x);
#endif
