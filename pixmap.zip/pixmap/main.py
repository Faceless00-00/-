import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton
from PyQt6.QtGui import QPixmap
import pymysql

class CartItemsWindow(QWidget):
    def __init__(self, items):
        super().__init__()
        self.setWindowTitle("Результаты")
        layout = QVBoxLayout()
        # Создание виджета для отображения результатов
        self.result_widget = QWidget()
        layout.addWidget(self.result_widget)
        result_layout = QVBoxLayout()
        self.result_widget.setLayout(result_layout)
        # Отображение данных в виджете
        for item in items:
            product_name_label = QLabel(f"Название продукта: {item[0]}")
            product_price_label = QLabel(f"Стоимость продукта: {item[1]}")
            quantity_label = QLabel(f"Количество: {item[2]}")
            date_label = QLabel(f"Дата добавления: {item[3]}")
            # Отображение изображения товара
            img_label = QLabel()
            img = QPixmap()
            img.loadFromData(item[4])
            img_label.setPixmap(img)
            img_label.setScaledContents(True)
            result_layout.addWidget(product_name_label)
            result_layout.addWidget(product_price_label)
            result_layout.addWidget(quantity_label)
            result_layout.addWidget(date_label)
            result_layout.addWidget(img_label)
        self.setLayout(layout)
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Получение элементов корзины")
        layout = QVBoxLayout()
        # Создание метки и поля для ввода имени клиента
        self.label_client_name = QLabel("Имя клиента:")
        self.entry_client_name = QLineEdit()
        layout.addWidget(self.label_client_name)
        layout.addWidget(self.entry_client_name)
        # Создание кнопки для отправки запроса
        self.submit_button = QPushButton("Готово")
        self.submit_button.clicked.connect(self.get_cart_items)
        layout.addWidget(self.submit_button)
        self.setLayout(layout)
    def get_cart_items(self):
        client_name = self.entry_client_name.text()
        items = self.fetch_cart_items(client_name)
        self.show_cart_items(items)
    def fetch_cart_items(self, client_name):
        cursor = None
        connection = None
        try:
            # Подключение к базе данных
            connection = pymysql.connect(host="localhost",user="root",password="",database="pybd")
            cursor = connection.cursor()
            # Выполнение хранимой процедуры с передачей параметра
            cursor.callproc('GetCustomerCartInfoWithImage', (client_name,))
            # Получение результата
            items = cursor.fetchall()
            return items
        except Exception as e:
            print(f"Произошла ошибка: {e}")
            return []
        finally:
            # Закрытие соединения
            if cursor:
                cursor.close()
            if connection:
                connection.close()
    def show_cart_items(self, items):
        self.cart_items_window = CartItemsWindow(items)
        self.cart_items_window.show()
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())





