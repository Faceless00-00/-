#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void read_file (const char* name, char* in_all_data){
    FILE* in = fopen(name, "r");
    if (in == NULL) {
        printf("error\n");
        return 1;
    }
    int i = 0;
    char ch;
    while ((ch = fgetc(in)) != EOF) {
        in_all_data[i++] = ch;
    }
    fclose(in);
    in_all_data[i++] = '\0';
}

 void write_file (const char * x){
    FILE* out = fopen(x, "a");
    if (out == NULL) {
        printf("error\n");
        return 1;
    }
    fclose(out);
}
