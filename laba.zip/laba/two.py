import MySQLdb as mbd

class Database:
    @staticmethod
    def serf_logs():
        try:
            ssl = {'ca': 'ca.pem', 'cert': 'client-cert.pem', 'key': 'client-key.pem'}
            con = mbd.connect (
                host = 'localhost',
                user = 'root',
                password = 'root',
                database = 'laba_1_suvorov',
                ssl = ssl
            )
            print('Connect OK')

            with con:
                cur = con.cursor()
                cur.execute('SELECT * FROM users')
                rows = cur.fetchall()
                return rows

        except:
            print("Failed")



